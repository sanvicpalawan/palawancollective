# Palawan Collective

> Stories, systems, and infrastructure from building off-grid resorts and
> automation ecosystems in Palawan.

A living field-journal website — not a portfolio, not a blog. It publishes
dispatches from an off-grid resort build, runs a WhatsApp-first AI operator,
and carries a hidden ops console for managing every part of the site.

## Tech stack

- **Next.js 16** (App Router, React 19, TypeScript)
- **PostgreSQL** via **Drizzle ORM** — Neon-ready (single `DATABASE_URL`)
- **Tailwind CSS 4**, **Framer Motion**, **Zustand**
- **JOSWE/jose** JWT sessions for the stealth admin
- **sharp** for logo/media optimization, **qrcode** for the footer WhatsApp QR

## Quick start

```
cp .env.example .env        # fill in DATABASE_URL (Neon pooled string) + keys
npm install
npx drizzle-kit push --force  # create the schema in your database
npm run dev
```

Content (stories, builds, guides, FAQs, partners, agents, design tokens)
seeds itself automatically on first use — no data setup required.

See **[DEPLOY.md](./DEPLOY.md)** for the full Neon walkthrough.

## The admin (ops console)

There is **no public login page**. Triple-click the site logo — or use the
discreet *Admin* control in the footer — and enter the 4-digit passkey
(`ADMIN_PASSKEY`).

| Code | Section | What it controls |
| ---- | ------- | ---------------- |
| 00 | Overview | Stats, traffic, inquiries, model routing, version history |
| 01 | Content Builder | Homepage sections: order, visibility, drafts, content fields |
| 02 | Design System | Colors, Google Fonts, type/space scale, radius, shadows — live |
| 03 | Media Library | Upload (optimized), tag, delete |
| 04 | Navigation | Header menu items |
| 05 | Newsletter | Copy, subscriber list, CSV export, provider hook |
| 06 | FAQ | Questions/answers, order, visibility |
| 07 | Galleries | Home gallery, items, layout |
| 08 | Agents | Create/start/stop AI agents, prompts, behavior rules, test bench |
| 09 | Models | OpenRouter (cloud) ↔ Ollama (local) routing, key, model catalog |
| 10 | Settings | Site identity, hero copy, contact, inquiries inbox |
| 11 | Social | Social profile links (GitHub, X, Instagram, …) |
| 12 | Logo | Site logo upload + per-surface sizes (hero/header/footer) |
| 13 | Partners | Partner wall: add/edit/delete logos, links, order |

Every save is snapshot-able: Admin → Version history → Restore.

## Code tree

```
.
├── .env.example              # environment template (copy to .env)
├── DEPLOY.md                 # Neon + production deployment guide
├── drizzle.config.ts         # Drizzle Kit config — reads DATABASE_URL
├── public/
│   └── images/               # bundled imagery + generated wordmark
│       └── partners/         # default partner logos (SVG)
├── uploads/                  # legacy disk uploads (git-ignored) — new uploads
│                             # are stored in Postgres (uploaded_files table)
└── src/
    ├── app/
    │   ├── page.tsx                  # home — ops-controlled section order
    │   ├── layout.tsx                # fonts, header/footer, runtime, chat
    │   ├── stories/                  # dispatches (list + [slug])
    │   ├── built/                    # built environments (list + [slug])
    │   ├── palawan/                  # practical guides (list + [slug])
    │   ├── work-with-us/             # services + inquiry form
    │   ├── admin/page.tsx            # ops console (passkey-gated)
    │   ├── uploads/[...path]/        # serves /uploads/* with a file whitelist
    │   ├── feed.xml/ · sitemap.ts · robots.ts · icon.svg · not-found.tsx
    │   └── api/
    │       ├── health/               # liveness
    │       ├── track/                # analytics events
    │       ├── subscribe/            # newsletter signups
    │       ├── inquiries/            # project/partnership inquiries
    │       ├── agent/chat/           # public AI operator (provider routing)
    │       ├── public/site/          # public dynamic bundle (design/nav/etc.)
    │       └── admin/                # console APIs (JWT-guarded)
    │           ├── login · logout · session · overview
    │           ├── sections · navigation · faqs · galleries
    │           ├── design · media · logo
    │           ├── newsletter · settings · versions
    │           ├── agents · model-config · models/refresh
    │           ├── social · partners · inquiries
    ├── components/
    │   ├── home/                     # hero, carousel, sections, partners wall
    │   ├── site/                     # header, footer, mobile nav, logo
    │   ├── ops/                      # console shell + 13 admin panels
    │   ├── StoryBody · StoryCard · SocialLinks · SubscribeForm
    │   ├── InquiryForm · AgentChat · RotatingBadge · ui.tsx
    ├── content/                      # seed content (inserted once, never overwritten)
    │   ├── stories.ts
    │   └── ecosystem.ts              # builds, guides, field log
    ├── db/
    │   ├── index.ts                  # Neon-ready pg Pool + Drizzle client
    │   └── schema.ts                 # all tables (content + control layer)
    └── lib/
        ├── data.ts                   # public content queries (db → seed fallback)
        ├── control.ts                # admin data layer + idempotent seeding
        ├── models.ts                 # OpenRouter / Ollama clients + fallback KB
        ├── ops-auth.ts               # passkey + JWT session (dual transport)
        ├── admin-store.ts            # Zustand console state
        ├── design.ts                 # design tokens + Google Fonts helpers
        ├── social.ts                 # social platform catalog
        ├── site.ts                   # site constants (contact, whatsapp, etc.)
        └── format.ts                 # dates, seasons, dispatch numbering
```

## Database tables

Content: `stories`, `builds`, `guides`, `field_log`, `galleries`
Audience: `subscribers`, `inquiries`, `analytics_events`
Control: `site_settings`, `site_sections`, `design_tokens`, `media_assets`,
`nav_items`, `social_links`, `partners`, `agents`, `model_config`,
`content_versions`, `agent_logs`, `uploaded_files` (stored uploads)
